import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderSlotComponent } from './header-slot.component';

describe('HeaderSlotComponent', () => {
  let component: HeaderSlotComponent;
  let fixture: ComponentFixture<HeaderSlotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HeaderSlotComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HeaderSlotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
