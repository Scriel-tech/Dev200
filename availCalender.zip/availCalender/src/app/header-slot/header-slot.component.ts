import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header-slot',
  templateUrl: './header-slot.component.html',
  styleUrls: ['./header-slot.component.css']
})
export class HeaderSlotComponent {
  @Input() value: string  = '';

  getSlotColor(): string{

    if(this.value == ''){
      return "borderless";
    }
    const pattern =  /\*/; ///^\d{4}-\d{2}-\d{2}$/;

    switch(pattern.test(this.value)){
      case true:
        console.log("true");
        return "dark"
      default:
        console.log("Not true")
        return "light"
    }
  }
}
