// calender-slot.component.ts
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-calender-slot',
  templateUrl: './calender-slot.component.html',
  styleUrls: ['./calender-slot.component.css']
})
export class CalenderSlotComponent {
  @Input() status: string = 'Full';
  @Input() start: number = 0;
  @Input() dateCode: number = 0;
  @Input() clickable: boolean = false; // Receive the clickable property
  @Output() slotClicked = new EventEmitter<string>();

  // Keep track of the initial Class so that if Changed to Selected, it can be returned
  defaultStatus: string = "";

  ngOnInit(): void {
    //This ensure that the default status is set only once
    this.defaultStatus = this.status;
  }

  getSlotClass(): string {
    switch (this.status) {
      case 'Full':
        return 'full-slot';
      case 'Not Available':
        return 'unavailable-slot';
      case 'Selected':
        return 'selected-slot';
      default:
        return 'available-slot';
    }
  }

  onSlotClick(): void {
    console.log(this.defaultStatus);
    if (this.clickable) { // Only emit click event if the slot is clickable
      this.slotClicked.emit(this.defaultStatus);
    }
  }
}
