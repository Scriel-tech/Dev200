import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NumberSliderComponent } from './number-slider/number-slider.component';
import { FormsModule } from '@angular/forms';
import { CalenderComponent } from './calender/calender.component';
import { CalenderSlotComponent } from './calender-slot/calender-slot.component';
import { HeaderSlotComponent } from './header-slot/header-slot.component';


@NgModule({
  declarations: [
    AppComponent,
    NumberSliderComponent,
    CalenderComponent,
    CalenderSlotComponent,
    HeaderSlotComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
