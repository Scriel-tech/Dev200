import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-number-slider',
  templateUrl: './number-slider.component.html',
  styleUrl: './number-slider.component.css'
})
export class NumberSliderComponent {
  @Output() sliderValueChanged = new EventEmitter<number>();
  selectedNumber = 1;

  onSliderChange(): void {
    this.sliderValueChanged.emit(this.selectedNumber);
  }
}
