// calender.component.ts
import { Component, Input, OnInit, SimpleChanges, OnChanges } from '@angular/core';

interface Slot {
  type: string,
  status: string;
  clickable: boolean;
  defaultStatus: string;
}

@Component({
  selector: 'app-calender',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.css']
})
export class CalenderComponent implements OnInit, OnChanges {
  @Input() jobLength: number = 1; // Default value is 1 hour
  data = [
    { "Date": "2016-05-18", "HoursAvailable": [9, 10, 11, 12, 13, 14, 17] },
    { "Date": "2016-05-19", "HoursAvailable": [9, 10, 11, 12, 13, 14, 15, 16, 17] },
    { "Date": "2016-05-20", "HoursAvailable": [9, 10, 14, 15, 16, 17] },
    { "Date": "2016-05-21", "HoursAvailable": [9, 10, 11, 12, 13] },
    { "Date": "2016-05-23", "HoursAvailable": [13, 14, 15, 16] },
    { "Date": "2016-05-24", "HoursAvailable": [11, 12, 15, 16, 17] }
  ];

  table: Slot[][] = [];

  ngOnInit(): void {
    this.createTable();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['jobLength'] && !changes['jobLength'].firstChange) {
      this.createTable();
    }
  }

  onSlotClick(rowIndex: number, date: string): void {
    const timeSlot = rowIndex + 9;
    console.log('Slot clicked:', timeSlot, date);
    // Add your logic for handling slot click here
  }

  checkSlotAvailability(time: number, jobLength: number, date: string, hoursAvailable: number[]): { status: string; clickable: boolean } {  
    const today = new Date().toISOString().split('T')[0];
    const bufferBefore = (time === 9) ? 0 : (today === date) ? 2 : 1;
    const bufferAfter = (time !== 17) ? 1 : 0;
    const slotStart = time - bufferBefore;
    const slotEnd = time + jobLength + bufferAfter;
    
    //Check if the time is in hoursAvailable
    //If 

    const availableHours = hoursAvailable.filter(hour =>
      hour >= slotStart && hour < slotEnd
    );

    const isAvailable = availableHours.length === jobLength + bufferBefore + bufferAfter;
    const status = hoursAvailable.includes(time) ? (isAvailable ? 'Available' : 'Not Available') : "Full";
  
    return { status: status, clickable: isAvailable };
  }

  createTable(): void {
    this.table = [];

    // Add column headers
    const columnHeader: Slot[] = [ {type:'header', status: '', clickable: false, defaultStatus: '' }, ...this.data.map(item => ({type:'header', status: item.Date, clickable: false, defaultStatus: '' }))];
    this.table.push(columnHeader);

    for (let timeSlot = 9; timeSlot <= 17; timeSlot++) {
      const row: Slot[] = [];

      // Add row header
      const minutes = ':00';
      const next = timeSlot + 1;
      var adjustedTime = timeSlot < 10 ? '0' + timeSlot + minutes : timeSlot + minutes ;
      adjustedTime = adjustedTime + " - " + next + minutes;
      row.push({type:'header', status: adjustedTime, clickable: false, defaultStatus: '' });
      var i = 1;

      for (const item of this.data) {
        const { status, clickable } = this.checkSlotAvailability(timeSlot, this.jobLength, item.Date, item.HoursAvailable);

        // Set clickable property only for 'AVAILABLE' slots
        row.push({type:'slot', status: status, clickable: clickable && status === 'Available', defaultStatus: status  });
        i++;
      }

      console.log(this.table);
      this.table.push(row);
    }
  }

  handleSlotClick(defaultStatus: string, cell: Slot, rowIndex: number, cellIndex: number): void {
    console.log(`Slot clicked at row ${rowIndex}, column ${cellIndex}. Status: ${cell.status} . with . ${defaultStatus} . status `);
    
    var newStatus = this.table[rowIndex][cellIndex].status=="Available" ? "Selected" : "Available";

    for(var i=0; i<this.jobLength; i++)
    {
      
      this.table[rowIndex + i][cellIndex].status = newStatus == "Available" ? this.table[rowIndex + i][cellIndex].defaultStatus : "Selected";
    }
  }

}
